import pygame
prop_data = {
    "Pillar":{"image": pygame.image.load("Props/Column.png"), "collectable": False, "coin_num":0},
    "Coin":{"image": pygame.image.load("Props/Coin.png"), "collectable": True, "coin_num": 1},
}